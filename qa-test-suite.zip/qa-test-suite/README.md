# QA API Test Suite

![Playwright](https://img.shields.io/badge/Playwright-1.44-green) ![CI](https://img.shields.io/badge/CI-GitHub%20Actions-blue) ![Status](https://img.shields.io/badge/Tests-Passing-brightgreen)

A professional API test suite built with **Playwright**, demonstrating end-to-end API testing skills including CRUD operations, status code validation, response schema checks, and CI/CD integration via GitHub Actions.

---

## 🧪 What's Tested

| Endpoint | Method | Test Case |
|----------|--------|-----------|
| `/posts` | GET | Returns 100 posts with correct structure |
| `/posts/:id` | GET | Returns correct post by ID |
| `/posts` | POST | Creates a new post successfully |
| `/posts/:id` | PUT | Updates existing post |
| `/posts/:id` | DELETE | Deletes post, returns 200 |
| `/posts/99999` | GET | Invalid ID returns 404 |
| `/users` | GET | Returns array of users |
| `/users/:id` | GET | User has required fields (id, name, email, address) |
| `/users/:id/posts` | GET | Returns only posts belonging to that user |

---

## 🛠 Tech Stack

- **[Playwright](https://playwright.dev/)** — Test framework
- **[JSONPlaceholder](https://jsonplaceholder.typicode.com/)** — Public REST API used for testing
- **GitHub Actions** — CI/CD pipeline (tests run automatically on every push)

---

## 🚀 How to Run Locally

```bash
# 1. Clone the repo
git clone https://github.com/Iboyi-Oghenefejiro/qa-test-suite.git
cd qa-test-suite

# 2. Install dependencies
npm install
npx playwright install

# 3. Run all tests
npm test

# 4. View HTML report
npx playwright show-report
```

---

## 📁 Project Structure

```
qa-test-suite/
├── tests/
│   └── api.test.js        # All API test cases
├── .github/
│   └── workflows/
│       └── ci.yml         # GitHub Actions CI pipeline
├── playwright.config.js   # Playwright configuration
├── package.json
└── README.md
```

---

## 👤 Author

**Oghenefejiro Iboyi**  
QA Engineer & Cybersecurity Officer — Lagos, Nigeria  
📧 iboyioghenefejiro24@gmail.com

---

> This project is part of my professional portfolio demonstrating hands-on API testing experience with modern tooling.
