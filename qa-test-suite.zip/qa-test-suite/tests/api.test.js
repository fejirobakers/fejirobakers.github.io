// API Testing Suite - Oghenefejiro Iboyi
// Tests against a public REST API (JSONPlaceholder) to demonstrate API testing skills

const { test, expect } = require('@playwright/test');

const BASE_URL = 'https://jsonplaceholder.typicode.com';

test.describe('API - Posts Endpoint', () => {

  test('GET /posts returns 100 posts', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/posts`);
    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body).toHaveLength(100);
  });

  test('GET /posts/:id returns correct post', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/posts/1`);
    expect(response.status()).toBe(200);
    const post = await response.json();
    expect(post).toHaveProperty('id', 1);
    expect(post).toHaveProperty('title');
    expect(post).toHaveProperty('body');
    expect(post).toHaveProperty('userId');
  });

  test('POST /posts creates a new post', async ({ request }) => {
    const newPost = { title: 'Test Post', body: 'This is a test.', userId: 1 };
    const response = await request.post(`${BASE_URL}/posts`, { data: newPost });
    expect(response.status()).toBe(201);
    const created = await response.json();
    expect(created).toHaveProperty('id');
    expect(created.title).toBe(newPost.title);
  });

  test('PUT /posts/:id updates a post', async ({ request }) => {
    const updated = { id: 1, title: 'Updated Title', body: 'Updated body.', userId: 1 };
    const response = await request.put(`${BASE_URL}/posts/1`, { data: updated });
    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body.title).toBe('Updated Title');
  });

  test('DELETE /posts/:id returns 200', async ({ request }) => {
    const response = await request.delete(`${BASE_URL}/posts/1`);
    expect(response.status()).toBe(200);
  });

  test('GET /posts/:id with invalid ID returns 404', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/posts/99999`);
    expect(response.status()).toBe(404);
  });

});

test.describe('API - Users Endpoint', () => {

  test('GET /users returns array of users', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/users`);
    expect(response.status()).toBe(200);
    const users = await response.json();
    expect(Array.isArray(users)).toBeTruthy();
    expect(users.length).toBeGreaterThan(0);
  });

  test('GET /users/:id has required fields', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/users/1`);
    const user = await response.json();
    expect(user).toHaveProperty('id');
    expect(user).toHaveProperty('name');
    expect(user).toHaveProperty('email');
    expect(user).toHaveProperty('address');
  });

  test('GET /users/:id/posts returns posts for user', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/users/1/posts`);
    expect(response.status()).toBe(200);
    const posts = await response.json();
    expect(Array.isArray(posts)).toBeTruthy();
    posts.forEach(post => expect(post.userId).toBe(1));
  });

});
